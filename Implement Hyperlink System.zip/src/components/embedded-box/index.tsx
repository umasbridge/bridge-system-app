export { EmbeddedBoxWorkspace } from './EmbeddedBoxWorkspace';
export { EmbeddedBoxElement } from './EmbeddedBoxElement';
export type { EmbeddedBoxElement as EmbeddedBoxElementType } from './types';
