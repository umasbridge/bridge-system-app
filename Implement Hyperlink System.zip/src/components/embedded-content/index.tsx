export { EmbeddedContentWorkspace } from './EmbeddedContentWorkspace';
export { EmbeddedContentElement } from './EmbeddedContentElement';
export type { EmbeddedContentElement as EmbeddedContentElementType } from './types';
